#ifndef ADD_NAME2FILE_H
    #define ADD_NAME2FILE_H
        char *name2File(char *myname);//将用户名改成以.txt结尾的文件
#endif  