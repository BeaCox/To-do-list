#ifndef deleteSpace_H
    #define deleteSpace_H
    char *deleteSpace(char *str);
#endif  